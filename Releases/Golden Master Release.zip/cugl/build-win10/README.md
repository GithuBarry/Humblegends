# Windows Libraries

Games written for Windows must have specific DLLs in order to run.  These dlls are stored in the `dlls` folder in this directory.  Whenever you make a new project, this folder must be copied to the top level of the `build-win10` directory.
