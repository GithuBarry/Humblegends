# CUGL Demos (Apple Platforms)

This directory contains the XCode project for for building and installing the 
the basic demo on OS X and iOS. This demo draws the logo and moves it about the screen. 
It also has a button to quit the application at the bottom of the screen.