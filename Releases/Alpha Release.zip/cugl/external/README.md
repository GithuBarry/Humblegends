# External Libraries

This directory holds the non-SDL third-party libraries that we will use in our game
engine.  For example, this is where we put Box2D.

Some of these libraries have their own projects.  Others, particularly the more simple
ones, are compiled directly in CUGL.
