//
//  TCU2DTest.hpp
//  CUGL
//
//  Created by Walker White on 6/26/16.
//  Copyright © 2016 Game Design Initiative at Cornell. All rights reserved.
//

#ifndef __T_CU_2D_TEST_H__
#define __T_CU_2D_TEST_H__

namespace cugl {
    
void testNode();
    
void sceneUnitTest();
    
}
#endif /* __T_CU_2D_TEST_H__ */
