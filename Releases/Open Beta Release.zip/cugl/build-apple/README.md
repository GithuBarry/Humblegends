# CUGL (Apple Platforms)

This directory contains CUGL build environment for Apple platforms.  You are free to
modify these classes if you have ideas for how to improve them.